import 'package:flutter/material.dart';
import 'package:fyp_therapy/core/constants/colors.dart';
import 'package:fyp_therapy/patient/screens/settings_screen.dart';
import 'package:fyp_therapy/therapist/screens/availability_screen.dart';
import 'package:fyp_therapy/therapist/screens/profile_screen.dart';
import '../widgets/therapist_greeting_card.dart';
import '../widgets/therapist_today_session_card.dart';
import '../widgets/quick_action_tile.dart';
import '../widgets/therapist_popup_menu.dart';

class TherapistHomeScreen extends StatelessWidget {
  const TherapistHomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none),
            onPressed: () {},
          ),

          TherapistPopupMenu(
            onSelected: (value) {
              if (value == 'availability') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AvailabilityScreen()),
                );
              } else if (value == 'profile') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ProfileScreen()),
                );
              } else if (value == 'settings') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SettingsScreen()),
                );
              }
            },
          ),

          const SizedBox(width: 12),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// 🔹 Greeting Card
            TherapistGreetingCard(),

            SizedBox(height: 22),

            /// 🔹 Quick Actions (Reused)
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 2.5,
              children: [
                QuickActionTile(
                  icon: Icons.assignment_late_outlined, // or Icons.mail_outline
                  label: 'Session Requests',
                  iconColor: AppColors.iconBookSession,
                  iconBackgroundColor: AppColors.iconBookSession.withOpacity(
                    0.3,
                  ),
                  onTap: () {
                    // Navigate to Session Requests Screen
                  },
                ),

                QuickActionTile(
                  icon: Icons.chat_bubble_outline,
                  label: 'View Chats',
                  iconColor: AppColors.iconChat,
                  iconBackgroundColor: AppColors.iconChat.withOpacity(0.3),
                  onTap: () {},
                ),
                QuickActionTile(
                  icon: Icons.people_outline,
                  label: 'My Patients',
                  iconColor: AppColors.iconTherapists,
                  iconBackgroundColor: AppColors.iconTherapists.withOpacity(
                    0.3,
                  ),
                ),
                QuickActionTile(
                  icon: Icons.insert_chart_outlined,
                  label: 'Reports',
                  iconColor: AppColors.iconMoodTracker,
                  iconBackgroundColor: AppColors.iconMoodTracker.withOpacity(
                    0.3,
                  ),
                  onTap: () {},
                ),
              ],
            ),

            /// 🔹 Today's Sessions Title
            SizedBox(height: 20),
            Text(
              "Today's Sessions",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),

            SizedBox(height: 10),

            /// 🔹 Example Session Cards
            TherapistTodaySessionCard(
              patientName: "Ali Khan",
              time: "10:00 AM",
              sessionType: "Video Session",
            ),

            SizedBox(height: 10),

            TherapistTodaySessionCard(
              patientName: "Sara Ahmed",
              time: "12:30 PM",
              sessionType: "In-Person",
            ),
          ],
        ),
      ),
    );
  }
}
